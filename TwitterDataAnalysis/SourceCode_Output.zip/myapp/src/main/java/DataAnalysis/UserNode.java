package DataAnalysis;

import java.util.LinkedList;

public class UserNode {

    String id;
    String screenName;
    String tweet;
    String createdAt;
    String geo;
    String inReplyToScreenName;
    String inReplyToUserId;
    String retweetCount;
    String source;
    LinkedList<UserNode>list;

}
